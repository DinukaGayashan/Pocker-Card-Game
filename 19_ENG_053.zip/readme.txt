Important
---------

All game activities are saved in the text file "Poker_Log.txt" according to their time.
Different games are printed by seperating a line of '-'. 
New logs are printed at the end of the file.

Please input 0/1 to withdraw/enter player to a round.
